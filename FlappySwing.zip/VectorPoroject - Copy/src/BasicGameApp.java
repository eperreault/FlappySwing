import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;


//*******************************************************************************
// Class Definition Section

public class BasicGameApp implements Runnable, KeyListener, MouseListener {

    //Variable Definition Section
    //Declare the variables used in the program
    //You can set their initial values too

    //Sets the width and height of the program window
    final int WIDTH = 1000;
    final int HEIGHT = 700;
    boolean spacePressed = false;
    public double angle = .01;
    public double radius;
    public double picAngle;
    public Swinger player;
    public ArrayList<Obstacle> obstacles;
    public Pivot[] pivots;
    boolean checkPivot = true;
    Pivot closestPivot;
    Pivot temp;
    public boolean isConnected;
    public boolean isFrozen;
    int difficulty;
    int alt = 1;
    //Declare the variables needed for the graphics
    public JFrame frame;
    public Canvas canvas;
    public JPanel panel;
    public Image background;
    public Image pipe;
    public Image pipe2;
    public Image playerImage;
    public Image floor;
    public Image city;
    public Image cloud;

    int score;
    int mouseX;
    int mouseY;
    double backgroundX;
    double floorX;
    double cityX;
    double cloudX;
    public Image menuButton;
    boolean outsideBoundingBox;
    public AffineTransform trans;
    public AffineTransform identity;
    public BufferStrategy bufferStrategy;
    public boolean gameStarted;


    //Declare the objects used in the program


    // Main method definition
    // This is the code that runs first and automatically
    public static void main(String[] args) {
        BasicGameApp ex = new BasicGameApp();   //creates a new instance of the game
        new Thread(ex).start();                 //creates a threads & starts up the code in the run( ) method
    }


    // Constructor Method
    // This has the same name as the class
    // This section is the setup portion of the program
    // Initialize your variables and construct your program objects here.
    public BasicGameApp() {
        setUpGraphics();
        canvas.addKeyListener(this);
        canvas.addMouseListener(this);
        pivots = new Pivot[2];
        obstacles = new ArrayList<>(2);

        makeObstacles();
        makePivots();

        trans = new AffineTransform();
        identity = new AffineTransform();

        background = Toolkit.getDefaultToolkit().getImage("Background.png");
        pipe = Toolkit.getDefaultToolkit().getImage("pipe.png");
        pipe2 = Toolkit.getDefaultToolkit().getImage("upsideDownPipe.png");
        playerImage = Toolkit.getDefaultToolkit().getImage("flappyBird.png");
        menuButton = Toolkit.getDefaultToolkit().getImage("button.png");
        floor = Toolkit.getDefaultToolkit().getImage("floor.png");
        city = Toolkit.getDefaultToolkit().getImage("City.png");
        cloud = Toolkit.getDefaultToolkit().getImage("Cloud.png");
        //variable and objects
        //create (construct) the objects needed for the game and load up
        player = new Swinger(100, 350);


        render();

    }

    // BasicGameApp()


//*******************************************************************************
//User Method Section
//
// put your code to do things here.

    // main thread
    // this is the code that plays the game after you set things up
    public void run() {
        while (true) {
            if (!gameStarted) {
                renderStartMenu();

                startGame();
            }
            if (gameStarted) {

                mouseX=0;
                mouseY=0;

                setPicAngle();
                checkConnection();


                move();

                movePivots();

                moveObstacles();

                boundingBox();
                checkCollision();
                increaseDifficulty();
                render();

            }

            pause(10);
        }

    }

    //paints things on the screen using bufferStrategy
    public void render() {

        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);

        //draw things
        if(player.xpos>400){
            backgroundX-=.0007*Math.pow(player.xpos-400,2);
        }
        if(backgroundX<=-1500){
            backgroundX=0;
        }
        g.drawImage(background, (int) backgroundX,0,WIDTH+520,445,null);
        g.drawImage(background, (int) (backgroundX+1500),0,WIDTH+520,445,null);
        if(player.xpos>400){
            cloudX-=.001*Math.pow(player.xpos-400,2);
        }
        if(cloudX<=-1000){
            cloudX=0;
        }
        g.drawImage(cloud, (int) cloudX,420,WIDTH+20,60,null);
        g.drawImage(cloud, (int) (cloudX+1000),420,WIDTH+20,60,null);
        if(player.xpos>400){
        cityX-=.002*Math.pow(player.xpos-400,2);
        }
        if(cityX<=-1000){
            cityX=0;
        }
        g.drawImage(city, (int) cityX,450,WIDTH,201,null);
        g.drawImage(city, (int) (cityX+1000),450,WIDTH,201,null);

        floorX=obstacles.get(0).xpos-150;

        g.drawImage(floor, (int) floorX,650,WIDTH+200,50,null);
        g.drawImage(floor, (int) (floorX-1000),650,WIDTH+200,50,null);



        g.setColor(Color.BLACK);
        rotateImage();
        if (isConnected && player.isAlive) {
            g.setColor(Color.WHITE);
            g.drawLine((int) (player.xpos + 10), (int) (player.ypos + 10), closestPivot.xpos + closestPivot.width / 2, closestPivot.ypos + closestPivot.height / 2);
        }
        if (player.isAlive) {
            g.drawImage(playerImage, trans, null);
           
        }


        g.setColor(Color.WHITE);
        for (Pivot pivot : pivots) {
            g.fillOval(pivot.xpos, pivot.ypos, pivot.width, pivot.height);
        }

        for (Obstacle obstacle : obstacles) {
            g.drawImage(pipe2, obstacle.xpos, 0, 70, obstacle.height - obstacle.gap / 2, null);
            g.drawImage(pipe, obstacle.xpos, obstacle.height + obstacle.gap / 2, 70, HEIGHT- (obstacle.height + obstacle.gap / 2), null);
        }

        g.drawString("" + score, 100, 100);


        g.dispose();

        bufferStrategy.show();
    }

    public void renderStartMenu() {
        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);
        g.drawImage(background, (int) 0,0,WIDTH+520,445,null);
        g.drawImage(cloud, (int) 0,420,WIDTH+20,60,null);
        g.drawImage(city, (int) 0,450,WIDTH,201,null);
        g.drawImage(floor, (int) 0,650,WIDTH+200,50,null);
        g.drawImage(menuButton, 200, 400, 200, 75, null);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Flappy Bird", Font.PLAIN, 50));

        g.drawString("START", 257, 452);
        g.drawImage(menuButton, 600, 400, 200, 75, null);
        g.dispose();

        bufferStrategy.show();
    }

    //Pauses or sleeps the computer for the amount specified in milliseconds
    public void pause(int time) {
        //sleep
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {

        }
    }

    //Graphics setup method
    private void setUpGraphics() {
        frame = new JFrame("My First Game");   //Create the program window or frame.  Names it.

        panel = (JPanel) frame.getContentPane();  //sets up a JPanel which is what goes in the frame
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));  //sizes the JPanel
        panel.setLayout(null);   //set the layout

        // creates a canvas which is a blank rectangular area of the screen onto which the application can draw
        // and trap input events (Mouse and Keyboard events)
        canvas = new Canvas();
        canvas.setBounds(0, 0, WIDTH, HEIGHT);
        canvas.setIgnoreRepaint(true);

        panel.add(canvas);  // adds the canvas to the panel.

        // frame operations
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //makes the frame close and exit nicely
        frame.pack();  //adjusts the frame and its contents so the sizes are at their default or larger
        frame.setResizable(false);   //makes it so the frame cannot be resized
        frame.setVisible(true);      //IMPORTANT!!!  if the frame is not set to visible it will not appear on the screen!

        // sets up things so the screen displays images nicely.
        canvas.createBufferStrategy(2);
        bufferStrategy = canvas.getBufferStrategy();
        canvas.requestFocus();
        System.out.println("DONE graphic setup");

    }

    public void move() {


        if (player.isAlive) {
            player.rect = new Rectangle((int) player.xpos - 10, (int) player.ypos - 10, player.width, player.height);

        }
        if (spacePressed) {




            if (isConnected) {

                player.speed = 0.05;
                player.xpos = (closestPivot.xpos + Math.cos(angle) * radius);
                player.ypos = (closestPivot.ypos + Math.sin(angle) * radius);
                angle -= player.speed;
                picAngle = angle;
                player.dx = (closestPivot.xpos + Math.cos(angle) * radius) - (closestPivot.xpos + Math.cos(angle + player.speed) * radius);
                player.dy = (closestPivot.ypos + Math.sin(angle) * radius) - (closestPivot.ypos + Math.sin(angle + player.speed) * radius);
            }
        } else {
            isFrozen = false;
            closestPivot = closestPivot();
            if (player.xpos > closestPivot.xpos && player.ypos < closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos));
            }
            if (player.xpos < closestPivot.xpos && player.ypos < closestPivot.ypos) {
                angle = Math.atan((Math.abs(player.ypos - closestPivot.ypos)) / (Math.abs(player.xpos - closestPivot.xpos))) + (Math.PI) / 2;
            }
            if (player.xpos < closestPivot.xpos && player.ypos > closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos)) + Math.PI;
            }
            if (player.xpos > closestPivot.xpos && player.ypos > closestPivot.ypos) {
                angle = Math.atan((Math.abs(player.ypos - closestPivot.ypos)) / (Math.abs(player.xpos - closestPivot.xpos))) + 3 * Math.PI / 2;
            }
            if (player.ypos == closestPivot.ypos && player.xpos < closestPivot.xpos) {
                angle = Math.PI;
            }
            if (player.ypos == closestPivot.ypos && player.xpos > closestPivot.xpos) {
                angle = 0;
            }

            if (player.ypos + player.height > HEIGHT || player.ypos < 0) {
                player.speed = -player.speed;
            }


        }

        if (!isConnected) {
            closestPivot = closestPivot();
            if (player.xpos > closestPivot.xpos && player.ypos < closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos));
            }
            if (player.xpos < closestPivot.xpos && player.ypos < closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos)) + (Math.PI);
            }
            if (player.xpos < closestPivot.xpos && player.ypos > closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos)) + Math.PI;
            }
            if (player.xpos > closestPivot.xpos && player.ypos > closestPivot.ypos) {
                angle = Math.atan((player.ypos - closestPivot.ypos) / (player.xpos - closestPivot.xpos));
            }
            if (player.ypos == closestPivot.ypos && player.xpos < closestPivot.xpos) {
                angle = Math.PI;
            }
            if (player.ypos == closestPivot.ypos && player.xpos > closestPivot.xpos) {
                angle = 0;
            }

            if (player.ypos< 0 || player.ypos  + player.height > 650) {
                player.dy = -player.dy;
            }

            player.xpos += player.dx;


            player.tempDx = player.dx;
            player.ypos += player.dy;
            player.dy += .1;
            player.relativeX = closestPivot.xpos - player.xpos;
        }

        if(!player.isAlive)

    {
        player.xpos = -100000;
    }}



    public double distance(double xpos,double ypos,double xpos2,double ypos2){
        return(Math.sqrt(Math.pow(xpos-xpos2,2)+Math.pow(ypos-ypos2,2)));

    }
    public void makePivots(){



        for(int i=0;i<pivots.length;i++){
            pivots[i]= new Pivot(700+750*i, (int) (100*Math.random())+250);
        }

    }
    public void makeObstacles(){
        for(int i = 0; i<2;i++){
            obstacles.add( new Obstacle((int) +(950)+i*750, (int) (HEIGHT*Math.random()),(int)(50),(int)(100*Math.random()+300),(int)(Math.random()*50)+(400-score)));

        }
    }
    public Pivot closestPivot(){
       for(int i=0;i<pivots.length;i++) {
           for (int j = i+1; j < pivots.length; j++) {
               if(distance(player.xpos,player.ypos,pivots[i].xpos,pivots[i].ypos)>distance(player.xpos,player.ypos,pivots[j].xpos,pivots[j].ypos)){
                   temp = pivots[i];
                   pivots[i] =pivots[j];
                   pivots[j]=temp;

               }

           }

       }
       return pivots[0];
    }
    public void movePivots(){

            for (Pivot pivot:pivots) {
                if(pivot.xpos<10 ){
                    pivot.xpos=obstacles.get(1).xpos+375 ;
                }


                }
            }

    private void rotateImage( ) {

      double theta;		//variable to calculate the angle
        if(isConnected&&!isFrozen){
            theta=picAngle+3*Math.PI/2;
        }
        else if(isFrozen){
            theta= picAngle;
        }
        else{
        theta=picAngle;
        }
   	//Calculate the angle and use    an offset


   	//set up new transforms
      trans = new AffineTransform();
      trans.setTransform(identity);

   	//set the position of the picture on the offscreen image
      trans.translate(player.xpos,player.ypos);

   	//rotate the picture - use radians
      trans.rotate(theta);

   	//translate back. Use half the width and height
      trans.translate(-player.width-11,-player.height-12);
   }





    public void moveObstacles(){

        for (Obstacle obstacle :obstacles){

            obstacle.rect = new Rectangle(obstacle.xpos,0,70,obstacle.height-obstacle.gap/2);
            obstacle.rect2 = new Rectangle(obstacle.xpos,obstacle.height+obstacle.gap/2,70,1000);
        }
        for(int i =0; i< obstacles.size();i++){
            if(obstacles.get(i).xpos+(obstacles.get(i).width/2)<0){
                obstacles.remove(i);
                obstacles.add(new Obstacle((int) obstacles.get(0).xpos+700, (int) (HEIGHT*Math.random()),(int)(100*Math.random()+20),(int)(100*Math.random()+300), (int) (110+(40*Math.random())+(400-difficulty))));
                score+=10;
        }

    }
    }
    public void startGame(){
        if(mouseX>200&&mouseX<400&&mouseY>400&&mouseY<475) {


            gameStarted = true;
            player.isAlive = true;
        }

    }
    public void increaseDifficulty(){
        if(0<=score&&score<100){
            difficulty = 50;
        }
        if(100<=score&&score<200){
            difficulty = 100;
        }
        if(200<=score&&score<300){
            difficulty = 200;
        }
        if(200<=score&&score<300){
            difficulty = 200;
        }
        if(300<=score&&score<400) {
            difficulty = 300;
        }
        if(score>400){
            difficulty = 400;
        }
    }
    public void checkConnection(){
        if(spacePressed&&radius<350){
            isConnected = true;
        }
        else{
            isConnected=false;
        }
    }
        public void checkCollision(){
        if(!player.isAlive){

            pause(1000);

            restartGame();

        }
        for(Obstacle obstacle:obstacles) {
            if (player.rect.intersects(obstacle.rect) || player.rect.intersects(obstacle.rect2)) {


                player.isAlive = false;



                player.dx=0;

            }
        }
        }


    public void setPicAngle(){
            picAngle=Math.atan2(player.dy,player.dx);

        }
        public void boundingBox(){
            if(player.xpos>400){

                for(Obstacle obstacle:obstacles){

                    obstacle.xpos-=.005*Math.pow(player.xpos-400,2);
                }

                for(Pivot pivot:pivots){
                    pivot.xpos-=.005*Math.pow(player.xpos-400,2);
                }
                player.xpos-=.005*Math.pow(player.xpos-400,2);
            }



        }

    @Override
    public void keyTyped(KeyEvent e){

    }
    @Override
    public void keyReleased(KeyEvent e){
        int key = e.getKeyCode();
        if(key==KeyEvent.VK_SPACE) {

            spacePressed = false;
        }
            checkPivot = true;

    }
    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if(key ==KeyEvent.VK_SPACE){

            spacePressed=true;
            if(checkPivot ==true) {
                closestPivot = closestPivot();
                radius = distance(player.xpos, player.ypos, closestPivot.xpos, closestPivot.ypos);
                checkPivot = false;
            }
        }


    }
    public void restartGame(){
        gameStarted = false;
        score = 0;
        player = new Swinger(100,350);

        obstacles.clear();

        makeObstacles();
        makePivots();

    }


    @Override
    public void mouseClicked(MouseEvent e) {
        int x, y;
        x=e.getX();
        y=e.getY();
        mouseX=x;
        mouseY=y;
        System.out.println("hi");

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}