public class Pivot {
    public int xpos;
    public int ypos;
    public int width;
    public int height;
    public double centerX;
    public double centerY;
    public Pivot(int xpos, int ypos){
        this.xpos = xpos;
        this.ypos = ypos;
        centerX=xpos+(width/2);
        centerY=ypos+(height/2);
        width = 20;
        height = 20;
    }
}
