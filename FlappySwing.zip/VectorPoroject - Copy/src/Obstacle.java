import java.awt.*;

public class Obstacle {
    public int xpos;
    public int ypos;
    public int width;
    public int height;
    public Rectangle rect;
    public Rectangle rect2;
    public int gap;
    public Obstacle(int xpos, int ypos, int width, int height,int gap){
        this.xpos =xpos;
        this.ypos =ypos;
        this.height = height;
        this.width = width;
        this.gap = gap;
        rect= new Rectangle(xpos,ypos,width,height);
        rect2 = new Rectangle(xpos,700-height/2,width,height);
    }
}
