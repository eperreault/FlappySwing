import java.awt.*;

public class Swinger {
    public double xpos;
    public double ypos;
    public int width;
    public int height;
    public double speed;
    public double dx;
    public double dy;
    public boolean isAlive =true;
    public double tempDx;
    public double relativeX;
    public Rectangle rect;
    public Swinger(int xpos, int ypos){
        width = 40;
        height = 40;
        speed=.05;
        dx=3;
        dy=0;
        this.xpos = xpos;
        this.ypos = ypos;
        rect = new Rectangle(xpos-10,xpos-10,width,height);


    }

}
